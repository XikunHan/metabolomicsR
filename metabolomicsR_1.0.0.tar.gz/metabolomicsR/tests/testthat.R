library(testthat)
library(metabolomicsR)

test_check("metabolomicsR")
